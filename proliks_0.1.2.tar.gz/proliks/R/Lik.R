
as_Lik <- function(logLfn, lower, upper) {
  if ( ! is.function(logLfn)) stop("'logLfn' must be a function.")
  if (missing(lower)) stop("'lower' bounds (named numeric vector) must be provided.")
  fittedPars <- names(lower)
  if (is.null(fittedPars)) stop("'lower' names are missing.")
  if (missing(upper)) stop("'upper' bounds (named numeric vector) must be provided.")
  if ( ! setequal(fittedPars, names(upper))) stop("'upper' names do not match 'fittedPars'.")
  object <- list(logLfn=logLfn, 
                 colTypes= list(fittedPars=fittedPars),
                 lower=lower, upper=upper,
                 MSL=new.env(parent=parent.frame()),
                 CIobject=new.env(parent=parent.frame()))
  
  class(object) <- c("Lik", class(object))
  object
}

predict.Lik <- function(object, parvec, ...) {
  object$logLfn(parvec)
}

.confint <-  function(object, parm, ## parm is the parameter which CI is sought
                      givenmax=NULL,
                      lower=object$lower, upper=object$upper,
                      #Bartlett=0L,
                      level, # value of logLR  
                      verbose=interactive(),fixed=NULL,which=c(TRUE,TRUE),...) {
  if (is.null(givenmax)) stop("The point estimates should be computed before using 'confint'.")
  fixedPars <- names(fixed)   
  if ( ! is.null(bootreps <- object$bootLRTenv$bootreps_list[[sort(parm)]])) {
    meanLR <- mean(bootreps)
    level <- level *meanLR / length(parm)  # correcting the threshold: inverse of correcting the LR stat
  }
  fittedPars <- object$colTypes$fittedPars
  if (! is.null(fixed)) fittedPars <- setdiff(fittedPars,fixedPars)
  fittedparamnbr <- length(fittedPars) 
  MLval <- object$MSL$MSLE[parm]
  if (is.na(MLval)) {stop(paste("'",parm,"' appears to be an incorrect parameter name. Check 'parm'."))}
  lowval <- lower[parm]
  hival <- upper[parm]
  ## FR->FR uniroot has no parscale agument 
  tol <- .Machine$double.eps^0.25* (hival-lowval)
  if (tol< .Machine$double.eps ) {
    warning(paste("UPPER-LOWER range for",parm,"is as narrow as",signif(hival-lowval,3),
                  "\n which is likely to cause problems in various numerical procedures.\n Consider using another parameter scale."))
  }
  v <- object$MSL$MSLE; v[names(v)] <- NA ## create template 
  lowval <- lowval + 0.002 * (MLval - lowval)
  hival <- hival - 0.002 * (hival - MLval)
  shift <- givenmax - level  
  if (fittedparamnbr == 1) {
    profiledNames <- c()
    objectivefn1D <- function(CIvarval) {
      v[parm] <- CIvarval
      if (! is.null(fixed)) v[fixedPars] <- fixed[fixedPars]
      object$logLfn(v)+shift ## removed log... 
    }
    objectivefn <- objectivefn1D
  } else { 
    profiledNames <- names(lower)
    profiledNames <- setdiff(profiledNames, c(parm,fixedPars)) # [which( ! (profiledNames %in% parm))] 
    plower <- lower[profiledNames]
    pupper <- upper[profiledNames]
    objectivefnmultiD <- function(CIvarval,return.optim=FALSE) {
      #print(CIvarval)
      v[parm] <- CIvarval 
      plogL <- function(pparv) {
        v[profiledNames] <- pparv
        if (! is.null(fixed)) v[fixedPars] <- fixed[fixedPars]
        return(( - object$logLfn(v))) ## removed log...   
      }
      init <- object$MSL$MSLE[profiledNames]
      optr <- .safe_opt(init, plogL, lower=plower, upper=pupper, LowUp=list(), verbose=FALSE)
      if(return.optim) {
        optr$value <- - optr$objective 
        optr$par <- optr$solution
        return(optr)
      } else return(-optr$objective-shift) ## then returns shifted value for uniroot
    }
    objectivefn <- objectivefnmultiD    
  }
  CIlo <- NA
  CIup <- NA
  fupper <- level
  if (ML_at_bound <- (abs(lowval - MLval) < abs(MLval * 1e-08)) || !which[1]) {
    CIlo <- NA
    if (ML_at_bound && verbose) {
      mess <- paste0("Lower CI bound for ",parm," cannot be computed because point estimate is at lower bound of parameter range.")
      print(mess,quote=FALSE)
    }
  } else {
    flower <- objectivefn(lowval)
    if (is.na(flower)) {
      stop("From 'confint': 'flower' is NA")
    } else {
      if (flower < 0) {
        CIlo <- try((uniroot(objectivefn, interval = c(lowval, 
                                                       MLval), f.lower = flower, f.upper = fupper,tol=tol))$root, 
                    TRUE)
      } else if (verbose) {
        mess <- paste0("Lower CI bound for ",parm," cannot be computed as it appears to exceed the parameter range.")
        print(mess,quote=FALSE)
      }
    }
    if (inherits(CIlo,"try-error")) {
      CIlo <- NA
      errmsg <- paste("Lower CI bound for ", parm, " could not be computed (maybe out of sampled range)", 
                      sep = "")
      message(errmsg)
    } 
  }
  if (is.na(CIlo)) {
    lowfit <- NA
    lowerEstv <- NA
  } else {
    lowerEstv <- object$lower
    lowerEstv[parm] <- CIlo
    if (length(profiledNames)>0) {
      lowfit <- objectivefn(CIlo,return.optim=TRUE)
      lowerEstv[profiledNames] <- lowfit$par
    }      
  }
  ###
  flower <- fupper
  if ( ML_at_bound <- (abs(hival - MLval) < abs(MLval * 1e-08)) || !which[2]) {
    CIup <- NA
    if (ML_at_bound && verbose) {
      mess <- paste0("Upper CI bound for ",parm," cannot be computed because point estimate is at upper bound of parameter range.")
      print(mess,quote=FALSE)
    }
  } else {
    fupper <- objectivefn(hival)
    if (is.na(fupper)) {
      stop("From 'confint': 'fupper' is NA")
    } else {
      if (fupper < 0) {
        CIup <- try((uniroot(objectivefn, c(MLval, hival), 
                             f.lower = flower, f.upper = fupper,tol=tol))$root, 
                    TRUE)
      } else if (verbose) {
        mess <- paste0("Upper CI bound for ",parm," cannot be computed as it appears to exceed the parameter range.")
        print(mess,quote=FALSE)
      }
    }
    if (inherits(CIup,"try-error")) {
      CIup <- NA
      errmsg <- paste("Upper CI bound for ", parm, " could not be computed (maybe out of sampled range)", 
                      sep = "")
      message(errmsg)
    } 
  }
  if (is.na(CIup)) {
    upfit <- NA
    upperEstv <- NA
  } else {
    upperEstv <- object$upper
    upperEstv[parm] <- CIup
    if (length(profiledNames)>0) {
      upfit <- objectivefn(CIup,return.optim=TRUE)
      upperEstv[profiledNames] <- upfit$par
    } 
  }
  interval <- c(CIlo,CIup)
  names(interval) <- paste(c("low","up"),parm,sep=".")
  if (verbose) print(interval)
  invisible(list(lowerpar=lowerEstv,upperpar=upperEstv,interval=interval))
}

.check_identifiables <- function(hess, parnames, ad_hoc_mess="par"){
  npar <- ncol(hess)
  ev  <-  eigen(hess)
  zero.tol <- sqrt(.Machine$double.eps/7e-7) # the one sought for elements of the hessian matrix by hessian() default method. 
  which_lowev <-  which( ev$values < zero.tol*npar )
  if (length(which_lowev)) {
    which_lowest <- which.min(ev$values)
    absv <- abs(ev$vectors[,which_lowest])
    ord <- order(absv, decreasing = TRUE)
    if (absv[ord[2]]>0.001) { 
      bad <- parnames[ord[1:2]]
      if (ad_hoc_mess=="stat") {
        list(non=bad, message=paste0("statistic '",bad[1],"' appears linearly dependent with '",bad[2],"' and possibly some others."))
      } else list(non=bad, message=paste0("parameter '",bad[1],"' may be practically unidentifiable, possibly in combination with '",bad[2],"' and some others."))
    } else {
      bad <- parnames[ord[1]]
      list(non=bad, message=paste0("parameter '",bad[1],"' may be practically unidentifiable."))
    }
  } else return(list(non=NULL,message=NULL))
}



doMLfit <- function (object, lower=object$lower, upper=object$upper, 
                init=(upper+lower)/2, CIs=names(lower),level=0.95, method="Bhat::plkhci",
                verbose=interactive(),
                ...) { ##
  fittedPars <- object$colTypes$fittedPars
  parscale <- (upper-lower)
  logLfn <- object$logLfn
  objectivefn <- function(v) -logLfn(v)

  time1 <- Sys.time()
  if (verbose) cat("Maximization...")
  msl <- .safe_opt(init, objfn=objectivefn, 
                   lower=lower,upper=upper, LowUp=list(lower=lower,upper=upper), verbose=FALSE, ...)
  msl$par <- msl$solution
  names(msl$par) <- fittedPars
  msl$optim_time <- round(as.numeric(difftime(Sys.time(), time1, units = "secs")), 1) ## spaMM:::.timerraw(time1)
  msl$value <- - msl$objective 
  
  object$MSL$MSLE <- msl$par
  object$MSL$maxlogL <- msl$value 
  

  if (verbose) {
      cat("\n*ML: *\n")
      print(c(msl$par,"logL"=msl$value))
  }
  #
  hess <- try(numDeriv::hessian(objectivefn, msl$par), silent=TRUE)
  if (inherits(hess, "try-error")) {
    warning("Hessian computation failed: check whether estimates are at boundary of parameter space.") # FIXME
  } else {
    object$MSL$hessian <- hess
    
    rnge <- diag(x=sqrt(upper-lower), ncol=length(upper))
    sc_hess <- rnge %*% hess %*% rnge
    chk_identif <- .check_identifiables(sc_hess,parnames=names(msl$par))
    if (length(chk_identif$non)) message(chk_identif$message)
  }
  #
  prevmsglength <- 0L
  if( ! identical(CIs, FALSE) && length(CIs)) {
    chk <- setdiff(CIs, fittedPars)
    if (length(chk)) stop(paste("Parameter(s)",paste(chk,collapse=", "),"are not model parameters. Check 'CIs' argument"))
    locverbose <- (verbose && msl$optim_time*length(msl$par)>3) # guess when it is useful to be verbose from the time to find the maximum 
    if (locverbose) cat("Computing confidence intervals for:") 
    
    tmp <- vector("list", length(CIs))
    names(tmp) <- CIs
    CIs <- tmp
    for (st in names(CIs)) {
      if (locverbose) cat(" ", st)
      if (method=="Bhat::plkhci") {
        plkhci_info <- list(label=fittedPars,
                            est=msl$par,
                            low=lower,
                            upp=upper)
        CIs[[st]] <- .Bhat.plkhci(x=plkhci_info, 
                                  nlogf=objectivefn,
                                  label=st,prob=level, verbose=verbose>1L)
      } else CIs[[st]] <- .confint(object,parm=st,
                            level=qchisq(level,df=1)/2, # value of logLR   
                            givenmax= object$MSL$maxlogL, 
                            lower=lower, upper=upper,
                            fixed=NULL,
                            verbose=verbose,which=c(TRUE,TRUE))
    }
    if (locverbose) cat("\n")
    lowers <- lapply(CIs,function(li) {li$lowerpar})
    if ( ! is.null(lowers)) names(lowers) <-  paste("low.",names(lowers),sep="")
    uppers <- lapply(CIs,function(li) {li$upperpar})
    if ( ! is.null(uppers)) names(uppers) <-  paste("up.",names(uppers),sep="")
    # the list elements are either numeric vectors or asingle NA... 
    ordre <- order(c(seq_len(length(lowers)),seq_len(length(uppers))))
    bounds <- c(lowers,uppers)[ordre]
    checkvec <- function(vec) {if (identical(vec,NA)) {return(NULL)} else {return(vec)} }
    whichNAs <- unlist(lapply(bounds,function(vec) {identical(vec,NA)}))
    missingBounds <- names(bounds[whichNAs])
    bounds <- do.call(rbind,bounds[ ! whichNAs])
    object$CIobject$CIs <- CIs  
    object$CIobject$bounds <- bounds
  }
  # object$`Infusion.version` <- packageVersion("Infusion")
  invisible(object)
}




# generic from stats package: profile(fitted,...), returns a # *log*L
profile.Lik <- function(fitted, at, fixed=NULL, return.optim=FALSE, ...) {
  fixedPars <- names(fixed)   
  fittedPars <- fitted$colTypes$fittedPars
  if (! is.null(fixed)) fittedPars <- setdiff(fittedPars,fixedPars)
  fittedparamnbr <- length(fittedPars) 
  parm <- names(at)
  MLval <- fitted$MSL$MSLE[parm]
  if (anyNA(MLval)) {stop(paste("'",parm,"' appears to be an incorrect parameter name. Check 'parm'."))}
  lowval <- fitted$lower[parm]
  hival <- fitted$upper[parm]
  v <- fitted$MSL$MSLE; v[names(v)] <- NA ## create template 
  lowval <- lowval + 0.002 * (MLval - lowval)
  hival <- hival - 0.002 * (hival - MLval)
  logLfn <- fitted$logLfn
  if (fittedparamnbr == 1L) {
    v[parm] <- at
    if (! is.null(fixed)) v[fixedPars] <- fixed[fixedPars]
    resu <- logLfn(v)
  } else { 
    profiledNames <- names(fitted$lower)
    profiledNames <- setdiff(profiledNames, c(parm,fixedPars)) # [which( ! (profiledNames %in% parm))] 
    plower <- fitted$lower[profiledNames]
    pupper <- fitted$upper[profiledNames]
    v[parm] <- at 
    plogL <- function(pparv) {
      v[profiledNames] <- pparv
      if (! is.null(fixed)) v[fixedPars] <- fixed[fixedPars]
      return( - fitted$logLfn(v)) ## removed log... (log=TRUE is the default)  
    }
    # single optim from best clu mean by logLik 
    init <- fitted$MSL$MSLE  
    optr <- .safe_opt(init[profiledNames], plogL, lower=plower, upper=pupper, LowUp=list(), verbose=FALSE, ...)
    if(return.optim) {
      optr$value <- - optr$objective 
      optr$par <- optr$solution
      return(optr)
    } else return(- optr$objective) 
  }
} # *log*L

# Derived from Infusion:::.extract_intervals()
.extract_intervals <- function(object,verbose=interactive()) { ## extractor, no costly computation
  CIs <- object$CIobject$CIs
  lenCIs <- length(CIs)    
  pars <- names(CIs)
  resu <- rep(NA_real_,NROW(object$CIobject$bounds)) ## (over)size as the MSEs have no NAs
  names(resu) <- rownames(object$CIobject$bounds)
  map <- c(low=1L,up=2L)
  for (nam in rownames(object$CIobject$bounds)) {
    stterms <- regmatches(nam, regexpr("\\.", nam), invert = TRUE)[[1]] ## regmatches(<...>) splits at the first '.'
    parm <- stterms[2L]
    interval <- CIs[[parm]]$interval
    th <- interval[map[stterms[1L]]]
    resu[nam] <- th
  }
  if (verbose && length(resu)>0L) {
    par_headline <- "*** Profile-based interval estimates ***\n"
    cat(par_headline)
    print(resu)
    return(invisible(resu))
  } else return(resu) # may be zero-length vector if no interval info is available
}


summary.Lik <- function(object, #interval="Wald", 
                            level=0.95, verbose=TRUE, ...) {
  if ( ! is.null(MLE <- object$MSL$MSLE)) {
    cat("logL: ", object$MSL$maxlogL,"\n")
    
    beta_se <- sqrt(diag(solve(object$MSL$hessian)))
    beta_table <- cbind(Estimate=MLE,"Cond. SE"=beta_se)
    #if (interval=="Wald") {
    wdth <- beta_se*qnorm((1+level)/2)
    beta_table <- cbind(beta_table,"lower"=MLE-wdth, "upper"=MLE+wdth)
    #} 
    rownames(beta_table) <- names(MLE)
    if (verbose) {
      par_headline <- "*** Point estimates and 'Wald' intervals***\n"
      print(beta_table,4)
    }
    intervals <- .extract_intervals(object, verbose=verbose)
    resu <- list(beta_table=beta_table, intervals=intervals)
    invisible(resu)
  } else message("MLE has not yet been evaluated: run doMLfit().")
}

print.Lik <- function(x, ...) summary.Lik(object=x, level=0.95, ...)

logLik.Lik <- function(object, ...) object$MSL$maxlogL