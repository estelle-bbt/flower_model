set.seed(123)
x <- rnorm(50, 1, 2 )
## log likelihood function.
## Note: 'param' is a 2-vector c(mu, sd)
llf <- function(parvec) {
  mu <- parvec[1]
  sd <- parvec[2]
  llValue <- dnorm(x, mean=mu, sd=sd, log=TRUE)
  sum(llValue)
}
if (FALSE) {
  ## Estimate it with mu=0, sd=1 as start values
  ml <- maxLik(llf, start = c(mu=0, sigma=1) )
  print(summary(ml))
  
}

likS <- as_Lik(llf, lower=c(mu=-5,sd=0.001), upper=c(mu=5,sd=3))  
doMLfit(likS)

profile.likSurf(likS, at=c(mu=1))

summ <- summary.likSurf(likS)

likS$MSL$maxlogL-profile.likSurf(likS, at=c(mu=summ$beta_table["mu","lower"]))
# FIXME findroot not very accurate:
CIs <- doMLfit(likS)$CIobject$CIs
likS$MSL$maxlogL-profile.likSurf(likS, at=CIs$mu[["lowerpar"]]["mu"])
likS$MSL$maxlogL-profile.likSurf(likS, at=CIs$mu[["upperpar"]]["mu"])
likS$MSL$maxlogL-profile.likSurf(likS, at=CIs$sd[["lowerpar"]]["sd"])
likS$MSL$maxlogL-profile.likSurf(likS, at=CIs$sd[["upperpar"]]["sd"])
