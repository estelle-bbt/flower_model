".onAttach" <- function (lib, pkg) {
  version <- utils::packageVersion("proliks")
  packageStartupMessage("proliks (version ", version,
                        ") is loaded.",
                        "\nType 'help(proliks)' for a short introduction.")
}


