.proliks.data <- new.env(parent = emptyenv())
.proliks.data$options <- list(use_Bhat_logit=TRUE)

proliks.options <- function(..., warn=TRUE) {
  if (nargs() == 0) return(.proliks.data$options)
  temp <- list(...)
  if (length(temp) == 1 && is.null(names(temp))) {
    arg <- temp[[1]]
    switch(mode(arg),
           list = temp <- arg,
           character = return(.proliks.data$options[arg]),  ## return here for eg ... = "NUMAX"
           stop("invalid argument: ", sQuote(arg)))
  }
  if (length(temp) == 0) return(.proliks.data$options)
  argnames <- names(temp)
  if (is.null(argnames)) stop("options must be given by name")
  old <- .proliks.data$options[argnames] 
  if (anyNA(names(old))) { # has element(s) $<NA>=NULL 
    if (warn) {
      checknames <- argnames[which(is.na(names(old)))]
      checknames <- setdiff(checknames, c("sparse_precision")) # exception for valid names not in default proliks.options()
      if (length(checknames)) warning(paste0("'",paste(checknames,collapse="', '")),
                                      "' not previously in proliks.options. Check such name(s)?", immediate. = TRUE)
    }
    names(old) <- argnames 
  }
  .proliks.data$options[argnames] <- temp
  invisible(old)
}

proliks.getOption <- function (x) {proliks.options(x, warn=FALSE)[[1]]}

# additional (wrt .onLoad) operations when the package is visible to the user (:: not required to call a function)
".onAttach" <- function (lib, pkg) {
  version <- utils::packageVersion("proliks")
  packageStartupMessage("proliks (Rousset & Ferdy, 2014, version ", version, 
                        ## not sure this will always work and makes sense only for devel version :
                        # ", packaged ", utils::packageDescription("proliks")$Packaged,
                        ") is loaded.", 
                        "\nType 'help(proliks)' for a short introduction,",
                        "\n'news(package='proliks')' for news,",
                        "\nand 'citation('proliks')' for proper citation.",
                        "\nFurther infos, slides, etc. at https://gitlab.mbb.univ-montp2.fr/francois/proliks-ref.\n")
  #unlockBinding(".proliks", asNamespace("proliks")) ## required when a .proliks list was used instead of an envir
  
}

  